import React, { Component } from 'react';
import {View ,Image, FlatList, Text} from 'react-native';
import styles from './style';
const REQUEST_URL ='https://raw.githubusercontent.com/facebook/react-native/0.51-stable/docs/MoviesExample.json';
class DemoMovies extends Component {
    constructor(props) {
        super(props);
        this.state = {
             count:0 ,
            movies:null
        }
        this.fetchData=this.fetchData.bind(this);
    }
    fetchData(){
        fetch(REQUEST_URL)
        .then((response)=>response.json())
        .then((responseData)=>{
            this.setState({
                movies:responseData.movies
            })
        })
    }
    componentDidMount(){
        this.fetchData();
    }
    render() { 
        if(!this.state.movies)
            return this.renderLoadingView();

        return (
            <FlatList
            data={this.state.movies}
            renderItem={({item})=>this.renderMovie(item)}
            style={styles.list}
            keyExtractor={item=>item.id}
            ></FlatList>
        );
    }

    renderLoadingView(){
        
        return(
            <View style={styles.container}>
                <Text>
                    正在加载电影数据
                </Text>
            </View>
        );
    }

    renderMovie(movie){
        return (
            <View style={styles.container} 
            >
                <Image
                    title="图片"
                    source={{uri:movie.posters.thumbnail}}
                    style={styles.thumbnail}></Image>
                <View style={styles.rightContainer}>
                    <Text style={styles.title}
                          
                    >{movie.title}</Text>
                    <Text style={styles.year}>{movie.year}</Text>
                </View>
            </View>
        );
    }
}
 
export default DemoMovies;