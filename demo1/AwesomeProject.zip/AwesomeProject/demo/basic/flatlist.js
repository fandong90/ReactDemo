import React, { Component } from 'react';
import {FlatList ,View, Text } from 'react-native';
import styles from './style';
class DemoText extends Component{
    render(){
        return (
            <Text style={styles.button}>{this.props.name}</Text>
            )
    }
}

class DemoFlatList extends Component {
    _data=[
        {key:'1'},
        {key:'2'},
        {key:'3'},
        {key:'4'},
        {key:'5'},
        {key:'6'},
        {key:'7'},
        {key:'9'},
        {key:'10'},
        {key:'11'}
    ]
    render() { 
        return ( 
            <View style={styles.container}>
                <FlatList 
                    data={this._data}
                    renderItem={({item})=><DemoText name={item.key}></DemoText>}
                ></FlatList>
            </View>
         );
    }
}
 
export default DemoFlatList;