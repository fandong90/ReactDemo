import React, { Component } from 'react';
import {View,Button, Alert} from 'react-native';

class ButtonUser extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (  
            <View>
                <Button onPress={
                    ()=>{
                        Alert.alert('you click me !')
                    }
                }
                title="点我"/>
            </View>
        );
    }
}
 
export default ButtonUser;