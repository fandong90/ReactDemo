import React, { Component } from 'react';
import {View, Text} from 'react-native';
class FlexBox extends Component {
    constructor(props) {
        super(props);
        this.state = { count:0 }
    }
    render() { 
        return ( 
            <View style={{
                flex:1,
                flexDirection:'column',
                justifyContent:'flex-start'
            }}>
                <View style={{width:50,height:50,backgroundColor:'powderblue'}}></View>
                <View style={{width:50,height:50,backgroundColor:'skyblue'}}></View>
                <View style={{width:50,height:50,backgroundColor:'steelblue'}}></View>
            </View>
         );
    }
}
 
export default FlexBox;