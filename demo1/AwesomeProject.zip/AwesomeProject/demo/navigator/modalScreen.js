import React, { Component } from 'react';
import {View, Text, Button} from 'react-native';
import styles from '../basic/style';
class ModalScreen extends Component {
    state = {  count:0}
    render() { 
        return (  
            <View style={styles.container}>
                <Button
                    title="Dismiss"
                    onPress={()=>this.props.navigation.goBack()}
                >
                </Button>
            </View>
        );
    }
}
 
export default ModalScreen;