import React, { Component } from 'react';
import {View ,Text, Button,Alert} from 'react-native';
import styles from '../basic/style';
class DetailScreen extends Component {

    // static navigationOptions=({navigation})=>{
    //     return {
    //         title: navigation.getParam("id","No-id")
    //     };
    // };

    componentWillMount(){
        //Alert.alert("Will Mount... Details");
    }
    componentWillUnmount(){
        //Alert.alert("Unmount Details");
    }
    render() { 
        const {navigation} = this.props;
        const id=navigation.getParam("id","NO_ID");
        const other = navigation.getParam("other","no-done");

        return ( 
            <View style={styles.container}>
                <Text>DetailScreen</Text>
                <Button
                title="touch me"
                onPress={()=>this.props.navigation.navigate('Details')}
                ></Button>

                <Button
                title="go back"
                onPress={()=>this.props.navigation.goBack()}
                ></Button>
                <Text>{id} {other}</Text>
            </View>
         );
    }
}
 
export default DetailScreen;