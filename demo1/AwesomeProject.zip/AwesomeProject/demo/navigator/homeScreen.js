import React, { Component } from 'react';
import {View, Text,Button, Alert} from 'react-native';
import styles from '../basic/style';
class HomeScreen extends Component {
    static navigationOptions={
        headerTitle:<Text>'uuu'</Text>,
        headerRight:(
            <Button
                onPress={()=>Alert.alert("hehe")}
                title="Info"
                color="blue"
            />
        )
    };
    componentWillMount(){
        //Alert.alert("Will Mount... Home");
    }
    componentWillUnmount(){
        //Alert.alert("Unmount Home");
    }
    render() { 
        return (  
            <View style={styles.container}>
                <Text>Home Screen</Text>
                <Button
                    title="touch me"
                    onPress={()=>this.props.navigation.navigate('Details',{
                        id:'home1',
                        other:'done'
                    })}
                >
                </Button>
                <Button
                title="touch me"
                onPress={()=>this.props.navigation.navigate('ModalScreen',{
                    id:'home1',
                    other:'done'
                })}
            >
            </Button>
            </View>
        );
    }
}
export default HomeScreen;

