import React, { Component } from 'react';
import { createAppContainer, createStackNavigator} from 'react-navigation';
import HomeScreen from '../demo/navigator/homeScreen';
import DetailScreen from '../demo/navigator/detailsScreen';
import ModalScreen from '../demo/navigator/modalScreen';
const AppNavigator = createStackNavigator({
  Home:{
    screen: HomeScreen,
    navigationOptions: () => ({
      title: '首页'
    })
  },
  Details:{
    screen:DetailScreen,
    navigationOptions:({navigation})=>{
      return {title: navigation.getParam("id","no-id")};
    }
  },
  ModalScreen:{
      screen:ModalScreen,
      navigationOptions:()=>({
          title:'Modal'
      })
  }
},{
  initialRouteName:"Home",
  mode:'modal',
  //headerMode:'none'
});
const AppContainer=createAppContainer(AppNavigator);

export default AppContainer;
