/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';
import {
  createAppContainer, 
  createStackNavigator
} from 'react-navigation';
import styles from './demo/basic/style';
import FlexBox from './demo/basic/flexbox';
import PizzaTranslator from './demo/basic/inputText';
import ButtonUser from './demo/basic/button';
import Touchables from './demo/basic/touchable';
import DemoMovies from './demo/basic/movies';
import AppContainer from './route/appNavigator';
type Props = {};
export default class App extends Component<Props> {
  render() {
    return (
      /**
       * flexbox 布局学习
       */
      //<FlexBox></FlexBox>
      /**
       * textinput 学习
       */
      //<PizzaTranslator></PizzaTranslator>
      /**
       * Button 
       */
      //<ButtonUser/>
      /**
       * 定制按钮
       */
      //<Touchables></Touchables>
      /**
       * 滚动视图
       */
      //<DemoMovies></DemoMovies>
       <AppContainer />
    );
  }
}


